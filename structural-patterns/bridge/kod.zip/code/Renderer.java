public interface Renderer {
    void renderCircle(float radius);
    void renderRectangle(int height, int width);
}
